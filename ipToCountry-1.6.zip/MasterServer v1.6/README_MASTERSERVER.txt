Place this folder's contents (minus this file) on your web server running PHP.
You can now point your IpToCountry.ini file to your web server for queries.